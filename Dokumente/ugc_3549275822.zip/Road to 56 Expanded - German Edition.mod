version="2025-08-15"
tags={
	"Translation"
}
name="Road to 56 Expanded - German Edition"
supported_version="1.16.9"
path="C:/Users/jha/Documents/Paradox Interactive/Hearts of Iron IV/mod/Road to 56 Expanded - German Edition"
remote_file_id="3549275822"