version="2025-09-22"
tags={
	"Translation"
}
name="Road to 56 Expanded - German Edition"
supported_version="1.16.9"
path="D:/Spiele/SteamLibrary/steamapps/workshop/content/394360/3549275822"
remote_file_id="3549275822"