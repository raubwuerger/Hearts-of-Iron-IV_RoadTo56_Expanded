﻿Übersetzung für die mod The Road to 56 Expanded (Version 2025-08-05)

Mein Dank geht an die tolle Arbeit der The Road to 56 Expanded Entwickler.
https://steamcommunity.com/sharedfiles/filedetails/?id=3506850939

History

Aktualisiert am		Version				Beschreibung
2025-08-15			2025-08-05			Komplette Neuübersetzung