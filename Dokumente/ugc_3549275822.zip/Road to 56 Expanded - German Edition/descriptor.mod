version="2025-11-23"
tags={
	"Translation"
}
name="Road to 56 Expanded - German Edition"
supported_version="1.17.*"
remote_file_id="3549275822"