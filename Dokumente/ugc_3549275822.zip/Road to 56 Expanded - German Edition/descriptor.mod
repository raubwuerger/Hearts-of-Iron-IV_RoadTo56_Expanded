version="2025-08-15"
tags={
	"Translation"
}
name="Road to 56 Expanded - German Edition"
supported_version="1.16.9"
remote_file_id="3549275822"